function [x_k] = ttls_my(V1,k)

% Initialization.
[n1,m1] = size(V1); n = n1-1;
if (m1 ~= n1), error('The matrix V1 must be square'), end
if (nargin == 1), k = n; end
lk = length(k);
if (min(k) < 1 | max(k) > n)
  error('Illegal truncation parameter k')
end
x_k = zeros(n,lk);

% Treat each k separately.
for j=1:lk
  i = k(j);
  v = V1(n1,i+1:n1); gamma = 1/(v*v');
  x_k(:,j) = - V1(1:n,i+1:n1)*v'*gamma;
end





