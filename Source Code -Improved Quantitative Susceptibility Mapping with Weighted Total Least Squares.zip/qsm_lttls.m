function [Xall, Enrm, Rnrm] = qsm_lttls(A, b, maxiter, x_true, mask)

beta = norm(b); U = (1 / beta)*b;
nrmtrue = norm(x_true(:));
B = []; V = []; 
normr = beta;
h = waitbar(0, 'Beginning iterations: please wait ...');
Enrm = ones(maxiter,1);
Rnrm = ones(maxiter,1);
Xall = ones(length(x_true(:)),maxiter);

for i = 1:maxiter+1 % Iteration (i=1) is just an initialization
    [U, B, V] = feval(@LBD, A, U, B, V, [], [], []);
    vector = (beta*eye(size(B,2)+1,1));
    
    if i >= 2 % Begin Lanczos iterations
        be = norm(b(:));
        bete = be.*eye(i+1,1);  
        [~, ~, Vb] = csvd([B,bete]);
        f = ttls_my(Vb,i);
        x = V*f;
        r = b(:) -  A(x(:),'notransp');
        normr = norm(r(:));
        Enrm(i,1) = norm(mask.*x(:)-x_true(:))/nrmtrue;
        Rnrm(i,1) = normr;
        Xall(:,i) = mask.*x(:);
   
    else % Before beginning regularization
        f = B \ vector;
        x = V*f;
        Xall(:,i) = mask.*x(:);
        Enrm(i,1) = norm(mask.*x(:)-x_true(:))/nrmtrue;
        Rnrm(i,1) = normr;
    end
    waitbar(i/(maxiter+1), h)
end
close(h)




