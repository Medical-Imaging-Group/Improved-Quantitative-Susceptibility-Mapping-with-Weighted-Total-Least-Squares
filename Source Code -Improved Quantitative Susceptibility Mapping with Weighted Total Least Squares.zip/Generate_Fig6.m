clear 
close all
clc

load phantom_RDF
load Truth

omega = zeros(1,6);
omega(1:2:end) = -matrix_size./2;
omega(2:2:end) = matrix_size./2;
matrix_size_pad = [130 130 116];
Dqsm       = dipole_kernel(matrix_size_pad, voxel_size, B0_dir);
Dqsm_shift = fftshift(Dqsm);

xtrue = double(real(qsmTruex{2}));
xtrue(Mask==1) = xtrue(Mask==1) - mean(xtrue(Mask==1)); 
xtrue(~Mask) = 0;

wdata = double(dataterm_mask(1,N_std,Mask)); 
Aqsm  = @(x) reshape(unpad(real(ifftn(Dqsm.*fftn(pad(reshape(x,matrix_size),matrix_size_pad)))),matrix_size),[],1);
bqsmTrue = reshape(Aqsm(xtrue),matrix_size);

bqsm = addNoise(bqsmTrue, 40, 'peak'); % adding noise
maxIter = 20; % number of LSQR iterations

wdata = wdata(:); % weights for data term

threshQSM = 1e-4;
Dt  = Dqsm;
Dt(abs(Dt)<threshQSM) = threshQSM;
data = unpad(real(ifftn(Dt.*fftn(pad(bqsm,matrix_size_pad)))),matrix_size);
wmask = Mask(:);

P = speye(prod(matrix_size));
P = P(:,Mask(:)==1);

A = @(x) wdata.*Aqsm(P*x); % forward
At = @(x) P'*Aqsm(wdata.*x); % adjoint
Afun3 = @(v,flag) afun(A,At,v,flag);

load('Gadolinium_Phantom.mat');
%% Lanczos TTLS

[Xall, Enrm, Rnrm] = qsm_lttls(Afun3, wdata.*double(bqsm(:)), maxIter, P'*xtrue(:), 1);
[mE_ttls,iE_ttls] = min(Enrm(:)); 
vttls = Xall(:,iE_ttls);
x_ttls = P*vttls;

%% Sparse Total Least Squares (Sparse TLS)
Err1 = zeros(130,130,116);

for iter = 1:30
    x_stls = sparse_tv_qsm(xtrue, Dqsm, bqsm, Err1); 

    conj_psi = conj(x_stls);
    abspsi = abs(x_stls).^2;
    frac = abspsi./(1+abspsi);
    sec = conj_psi - (frac.*conj_psi);
    fir = ifftn(Dqsm.*(fftn(x_stls)));
    Err2 = (bqsm - fir).*sec;
    
    norme(iter) = norm(Err2(:) - Err1(:));
%     if norme(iter) < 1e-3
%        break;
%     end

    Err1 = Err2;
end

%% Plots
x_lttls = reshape(x_ttls,130,130,116);
x_sptls = real(x_stls).*Mask;

xtrue = double(real(qsmTruex{2}));
Msk = qsmMask{2};

Itrue = generate_figure_Gadolinium(xtrue,Msk);
Ilttls = generate_figure_Gadolinium(x_lttls,Msk);
Istls = generate_figure_Gadolinium(x_sptls,Msk);

Ilttlsdiff = generate_figure_Gadolinium(reshape(abs(x_lttls-Mask.*xtrue),matrix_size),Msk);
Istlsdiff = generate_figure_Gadolinium(reshape(abs(x_sptls-Mask.*xtrue),matrix_size),Msk);

figure,imshow(Itrue,[]); colorbar;
figure,imshow(Ilttls,[]); colorbar;
figure,imshow(Istls,[]); colorbar;

figure,imshow(ones(192,192)-Ilttlsdiff,[]); 
figure,imshow(ones(192,192)-Istlsdiff,[]); 

%% Metrics
x_lttls = reshape(x_ttls,130,130,116);
x_sptls = real(x_stls).*Mask;

rmse_lttls = compute_rmse(x_lttls, xtrue)
rmse_sptls = compute_rmse(x_sptls, xtrue)

hfen_lttls = compute_hfen(x_lttls, xtrue)
hfen_sptls = compute_hfen(x_sptls, xtrue)

ssim_lttls = compute_ssim(x_lttls, xtrue)
ssim_sptls = compute_ssim(x_sptls, xtrue)


%%
ind = find(Itrue>0.53);
samp = zeros(192,192);
samp(ind) = 1;

samcon = bwconncomp(samp); % finding the connected components
pixels1 = samcon.PixelIdxList{3};
pixels2 = samcon.PixelIdxList{5};
pixels3 = samcon.PixelIdxList{6};
pixels4 = samcon.PixelIdxList{7};
pixels5 = samcon.PixelIdxList{8};

val1 = Itrue(pixels1);
mean_true1 = mean(val1(:));
val2 = Itrue(pixels2);
mean_true2 = mean(val2(:));
val3 = Itrue(pixels3);
mean_true3 = mean(val3(:));
val4 = Itrue(pixels4);
mean_true4 = mean(val4(:));
val5 = Itrue(pixels5);
mean_true5 = mean(val5(:));

val1 = Ilttls(pixels1);
mean_lttls1 = mean(val1(:));
val2 = Ilttls(pixels2);
mean_lttls2 = mean(val2(:));
val3 = Ilttls(pixels3);
mean_lttls3 = mean(val3(:));
val4 = Ilttls(pixels4);
mean_lttls4 = mean(val4(:));
val5 = Ilttls(pixels5);
mean_lttls5 = mean(val5(:));

val1 = Istls(pixels1);
mean_stls1 = mean(val1(:));
val2 = Istls(pixels2);
mean_stls2 = mean(val2(:));
val3 = Istls(pixels3);
mean_stls3 = mean(val3(:));
val4 = Istls(pixels4);
mean_stls4 = mean(val4(:));
val5 = Istls(pixels5);
mean_stls5 = mean(val5(:));

mean_true = [mean_true1; mean_true2; mean_true3; mean_true4; mean_true5];
mean_lttls = [mean_lttls1; mean_lttls2; mean_lttls3; mean_lttls4; mean_lttls5];
mean_stls = [mean_stls1; mean_stls2; mean_stls3; mean_stls4; mean_stls5];

% For lanczos truncated total least squares
coefstls = polyfit(mean_true(:), mean_lttls(:), 1);
mean_lsqro = sort(mean_lttls,'ascend');
mean_trueo = sort(mean_true,'ascend');
lo_lim = 0.4;
hi_lim = 1.2;
lfit = coefstls(1)*[lo_lim:0.1:hi_lim]+coefstls(2);
figure,plot([lo_lim:0.1:hi_lim],lfit,'-k'); hold on;
plot(mean_trueo(:),mean_lsqro(:),'*r');
legend('Fitted','Measured');
xlabel('True susceptibility');
ylabel('Measured susceptibility');

num2str(coefstls(1),'%02.2f'),'*x+',num2str(coefstls(2),'%02.2f')

% For sparse total least squares
coefstls = polyfit(mean_true(:), mean_stls(:), 1);
mean_lsqro = sort(mean_stls,'ascend');
mean_trueo = sort(mean_true,'ascend');
lo_lim = 0.4;
hi_lim = 1.2;
lfit = coefstls(1)*[lo_lim:0.1:hi_lim]+coefstls(2);
figure,plot([lo_lim:0.1:hi_lim],lfit,'-k'); hold on;
plot(mean_trueo(:),mean_lsqro(:),'*r');
legend('Fitted','Measured');
xlabel('True susceptibility');
ylabel('Measured susceptibility');

num2str(coefstls(1),'%02.2f'),'*x+',num2str(coefstls(2),'%02.2f')






