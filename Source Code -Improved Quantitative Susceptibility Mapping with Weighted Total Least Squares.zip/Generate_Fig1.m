clear 
close all
clc

load simu_RDF

omega = zeros(1,6);
omega(1:2:end) = -matrix_size./2;
omega(2:2:end) = matrix_size./2;
matrix_size_pad = [256 256 98];

Dqsm       = dipole_kernel(matrix_size_pad, voxel_size, B0_dir);
Dqsm_shift = fftshift(Dqsm);

%% QSM forward operator and data
xtrue = iMag;
xtrue(Mask==1) = xtrue(Mask==1) - mean(xtrue(Mask==1)); 
xtrue(~Mask) = 0;

wdata = double(dataterm_mask(1,N_std,Mask)); 
Aqsm  = @(x) reshape(unpad(real(ifftn(Dqsm.*fftn(pad(reshape(x,matrix_size),matrix_size_pad)))),matrix_size),[],1);
bqsmTrue = reshape(Aqsm(xtrue),matrix_size);
bqsm = addNoise(bqsmTrue, 40, 'peak'); % adding noise

maxIter = 20; % number of LSQR iterations
wdata = wdata(:); % weights for data term

% get QSM forward operator
threshQSM = 1e-4;
Dt  = Dqsm;
Dt(abs(Dt)<threshQSM) = threshQSM;
data = unpad(real(ifftn(Dt.*fftn(pad(bqsm,matrix_size_pad)))),matrix_size);
Aqsm   = @(x) reshape(unpad(real(ifftn(Dt.*fftn(pad(reshape(x,matrix_size),matrix_size_pad)))),matrix_size),[],1);
wmask = Mask(:);

P = speye(prod(matrix_size));
P = P(:,Mask(:)==1);

A = @(x) wdata.*Aqsm(P*x); % forward
At = @(x) P'*Aqsm(wdata.*x); % adjoint
Afun3 = @(v,flag) afun(A,At,v,flag);

load('phantom_data_40dB.mat'); % loading the data 

%% Lanczos TTLS

[Xall, Enrm, Rnrm] = qsm_lttls(Afun3, wdata.*double(bqsm(:)), maxIter, P'*xtrue(:), 1);
[mE_ttls,iE_ttls] = min(Enrm(:)); 
vttls = Xall(:,iE_ttls);
x_ttls = P*vttls;

%% Sparse Total Least Squares (Sparse TLS)
Err1 = zeros(256,256,98);

for iter = 1:30 % running for fixed number of iterations
    x_stls = sparse_tv_qsm(xtrue, Dqsm, bqsm, Err1); 

    conj_psi = conj(x_stls);
    abspsi = abs(x_stls).^2;
    frac = abspsi./(1+abspsi);
    sec = conj_psi - (frac.*conj_psi);
    fir = ifftn(Dqsm.*(fftn(x_stls)));
    Err2 = (bqsm - fir).*sec;
    
    norme(iter) = norm(Err2(:) - Err1(:));
%     if norme(iter) < 1e-3
%        break;
%     end

    Err1 = Err2;
end

%% Plots

x_lttls = reshape(x_ttls,256,256,98);
Itrue = viewOrthoSlices2D_phantom_view(flip(reshape(xtrue,matrix_size),1),[0 1 0 1 0 1],matrix_size);
Ilttls = viewOrthoSlices2D_phantom_view(flip(reshape(x_lttls,matrix_size),1),[0 1 0 1 0 1],matrix_size);
Ilttlsdiff = viewOrthoSlices2D_phantom_view(flip(reshape(abs(x_lttls-Mask.*xtrue),matrix_size),1),[0 1 0 1 0 1],matrix_size);

x_sptls = real(x_stls).*Mask;
Istls = viewOrthoSlices2D_phantom_view(flip(reshape(x_sptls,matrix_size),1),[0 1 0 1 0 1],matrix_size);
Istlsdiff = viewOrthoSlices2D_phantom_view(flip(reshape(abs(x_sptls-Mask.*xtrue),matrix_size),1),[0 1 0 1 0 1],matrix_size);

figure,imshow(Itrue,[]); colorbar;
figure,imshow(Ilttls,[]); colorbar;
figure,imshow(Istls,[]); colorbar;

figure,imshow(ones(190,545)-Ilttlsdiff,[]); 
figure,imshow(ones(190,545)-Istlsdiff,[]); 

%% Metrics

rmse_lttls = compute_rmse(x_lttls, xtrue) % Root mean square error
hfen_lttls = compute_hfen(x_lttls, xtrue) % High frequency error norm
ssim_lttls = compute_ssim(x_lttls, xtrue) % stucture similarity index


rmse_stls = compute_rmse(x_sptls, xtrue) 
hfen_stls = compute_hfen(x_sptls, xtrue)
ssim_stls = compute_ssim(x_sptls, xtrue) 





