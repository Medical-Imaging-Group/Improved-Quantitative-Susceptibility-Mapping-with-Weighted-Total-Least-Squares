% =========================================================================
% function  ph = viewOrthoSlices2D(img,omega,m,varargin)
%
% Last changed: Lars Ruthotto 2016/02/12
%
% Slice visualization of 3D image.
%
% Input:
%  img   - image data, 3D array
%  omega - image domain
%  m     - voxel size
%
% Output:
%  ph    - plot handle
% =========================================================================
function I = viewOrthoSlices2D_myrealnew(img,omega,m,varargin)

if nargin==0
    runMinimalExample;
    return;
end

slices = ceil(m./2);
color = [.99 0.99 .99];

h = (omega(2:2:end)-omega(1:2:end))./m;
for k=1:2:length(varargin),     % overwrites default parameter
    eval([varargin{k},'=varargin{',int2str(k+1),'};']);
end;
% create big image
img = reshape(img,m);
Ixz = squeeze(img(:,slices(2),:)); % xz view
Iyz = squeeze(img(slices(1),:,:)); % yz view
Ixy = squeeze(img(:,:,slices(3))); % xy view

%Ii   = [zeros(15,256); Ixz'; zeros(14,256); ones(1,256) ; zeros(15,256); Iyz'; zeros(15,256)];     
%I   = [Ii ones(256,1) flipud(Ixy)];

I = [flipud(Iyz') flipud(Ixz') Ixy'];

function runMinimalExample

m      = [8 14 24];
omega  = [0 2 0 4 0 1];
h      = (omega(2:2:end)-omega(1:2:end))./m;

x = h(1)/2:h(1):omega(2);
y = h(2)/2:h(2):omega(4);
z = h(3)/2:h(3):omega(6);

[X,Y,Z] = ndgrid(x,y,z);

figure(1); clf;
viewOrthoSlices2D(flipdim(X,1),omega,m);


