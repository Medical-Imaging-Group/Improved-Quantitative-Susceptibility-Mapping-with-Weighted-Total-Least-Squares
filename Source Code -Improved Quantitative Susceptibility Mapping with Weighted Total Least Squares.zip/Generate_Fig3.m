clear

snrdata = 20:10:60;

for i = 1:length(snrdata)
    snrin = snrdata(i);
    [rmse, hfen, ssim] = various_snr(snrin);

    rmse_noise_ttls(i) = rmse(1);
    hfen_noise_ttls(i) = hfen(1);
    ssim_noise_ttls(i) = ssim(1);
    
    rmse_noise_stls(i) = rmse(2);
    hfen_noise_stls(i) = hfen(2);
    ssim_noise_stls(i) = ssim(2);
end


